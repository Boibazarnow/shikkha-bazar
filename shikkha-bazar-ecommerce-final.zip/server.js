require('dotenv').config();
const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const uploadsDir = path.join(__dirname, 'uploads');
fs.mkdirSync(uploadsDir, { recursive: true });
const db = new Database(path.join(__dirname, 'store.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS admins (id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT NOT NULL, description TEXT DEFAULT '', price INTEGER NOT NULL CHECK(price >= 0), stock INTEGER NOT NULL DEFAULT 0 CHECK(stock >= 0), image TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY AUTOINCREMENT, customer_name TEXT NOT NULL, phone TEXT NOT NULL, address TEXT NOT NULL, note TEXT DEFAULT '', items_json TEXT NOT NULL, total INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'Pending', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
`);
const adminUsername = process.env.ADMIN_USERNAME || 'admin';
const adminPassword = process.env.ADMIN_PASSWORD;
if (!adminPassword || adminPassword.length < 12) {
  console.error('SETUP ERROR: Add ADMIN_PASSWORD (at least 12 characters) to .env before starting.');
  process.exit(1);
}
const existing = db.prepare('SELECT id FROM admins WHERE username = ?').get(adminUsername);
if (!existing) db.prepare('INSERT INTO admins (username, password_hash) VALUES (?, ?)').run(adminUsername, bcrypt.hashSync(adminPassword, 12));

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '100kb' }));
app.use(express.urlencoded({ extended: true, limit: '100kb' }));
app.use(session({
  name: 'shikkha.sid',
  secret: process.env.SESSION_SECRET || 'development-only-change-this-secret-before-deploying',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 1000 * 60 * 60 * 8 }
}));
app.use('/uploads', express.static(uploadsDir, { maxAge: '1d' }));
app.use(express.static(path.join(__dirname, 'public')));
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false });
const storage = multer.diskStorage({ destination: uploadsDir, filename: (req, file, cb) => cb(null, Date.now() + '-' + Math.random().toString(36).slice(2, 10) + path.extname(file.originalname).toLowerCase()) });
const upload = multer({ storage, limits: { fileSize: 3 * 1024 * 1024 }, fileFilter: (req, file, cb) => cb(null, ['image/jpeg', 'image/png', 'image/webp', 'image/gif'].includes(file.mimetype)) });
const requireAdmin = (req, res, next) => req.session.adminId ? next() : res.status(401).json({ error: 'Please log in as admin.' });
const clean = (v, max = 500) => String(v ?? '').trim().slice(0, max);
const normalizePhone = v => String(v ?? '').replace(/[০-৯]/g, d => String('০১২৩৪৫৬৭৮৯'.indexOf(d))).replace(/[^0-9+()\s-]/g, '').trim();

app.get('/api/products', (req, res) => {
  const q = clean(req.query.q, 100), category = clean(req.query.category, 100);
  let sql = 'SELECT id,name,category,description,price,stock,image FROM products WHERE stock >= 0';
  const args = [];
  if (q) { sql += ' AND (name LIKE ? OR description LIKE ?)'; args.push('%' + q + '%', '%' + q + '%'); }
  if (category) { sql += ' AND category = ?'; args.push(category); }
  sql += ' ORDER BY id DESC';
  res.json(db.prepare(sql).all(...args));
});
app.get('/api/categories', (req, res) => res.json(db.prepare('SELECT DISTINCT category FROM products ORDER BY category').all().map(x => x.category)));
app.post('/api/orders', (req, res) => {
  const name = clean(req.body.name, 100), phone = normalizePhone(req.body.phone), address = clean(req.body.address, 500), note = clean(req.body.note, 500);
  const items = req.body.items;
  if (!name || !/^[-+()\d\s]{8,20}$/.test(phone) || !address || !Array.isArray(items) || items.length < 1 || items.length > 50) return res.status(400).json({ error: 'নাম, সঠিক ফোন নম্বর, ঠিকানা ও পণ্য নির্বাচন করুন।' });
  const normalized = [];
  let total = 0;
  for (const item of items) {
    const id = Number(item.id), qty = Number(item.qty);
    if (!Number.isInteger(id) || !Number.isInteger(qty) || qty < 1 || qty > 50) return res.status(400).json({ error: 'পণ্যের পরিমাণ সঠিক নয়।' });
    const product = db.prepare('SELECT id,name,price,stock FROM products WHERE id = ?').get(id);
    if (!product || product.stock < qty) return res.status(400).json({ error: `“${product ? product.name : 'পণ্য'}” পর্যাপ্ত স্টকে নেই।` });
    normalized.push({ id: product.id, name: product.name, price: product.price, qty }); total += product.price * qty;
  }
  const createOrder = db.transaction(() => {
    for (const item of normalized) {
      const result = db.prepare('UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?').run(item.qty, item.id, item.qty);
      if (!result.changes) throw new Error('স্টক পরিবর্তিত হয়েছে। আবার চেষ্টা করুন।');
    }
    const result = db.prepare('INSERT INTO orders (customer_name,phone,address,note,items_json,total) VALUES (?,?,?,?,?,?)').run(name, phone, address, note, JSON.stringify(normalized), total);
    return result.lastInsertRowid;
  });
  try { const id = createOrder(); res.status(201).json({ message: 'অর্ডার সফলভাবে গ্রহণ করা হয়েছে।', orderId: id, total }); }
  catch (e) { res.status(400).json({ error: e.message || 'অর্ডার করা যায়নি।' }); }
});
app.post('/api/admin/login', loginLimiter, (req, res) => {
  const username = clean(req.body.username, 100), password = String(req.body.password || '');
  const admin = db.prepare('SELECT id,password_hash FROM admins WHERE username = ?').get(username);
  if (!admin || !bcrypt.compareSync(password, admin.password_hash)) return res.status(401).json({ error: 'Username or password is incorrect.' });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: 'Could not create session.' });
    req.session.adminId = admin.id;
    res.json({ message: 'Logged in.' });
  });
});
app.post('/api/admin/logout', requireAdmin, (req, res) => req.session.destroy(() => res.json({ message: 'Logged out.' })));
app.get('/api/admin/me', (req, res) => res.json({ loggedIn: Boolean(req.session.adminId) }));
app.get('/api/admin/products', requireAdmin, (req, res) => res.json(db.prepare('SELECT * FROM products ORDER BY id DESC').all()));
app.post('/api/admin/products', requireAdmin, upload.single('image'), (req, res) => {
  const name = clean(req.body.name, 200), category = clean(req.body.category, 100), description = clean(req.body.description, 2000);
  const price = Number(req.body.price), stock = Number(req.body.stock);
  if (!name || !category || !Number.isInteger(price) || price < 0 || !Number.isInteger(stock) || stock < 0) return res.status(400).json({ error: 'সব তথ্য সঠিকভাবে দিন। দাম ও স্টক পূর্ণ সংখ্যা হতে হবে।' });
  const image = req.file ? '/uploads/' + req.file.filename : '';
  const result = db.prepare('INSERT INTO products (name,category,description,price,stock,image) VALUES (?,?,?,?,?,?)').run(name, category, description, price, stock, image);
  res.status(201).json({ id: result.lastInsertRowid });
});
app.put('/api/admin/products/:id', requireAdmin, upload.single('image'), (req, res) => {
  const id = Number(req.params.id), old = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
  if (!old) return res.status(404).json({ error: 'Product not found.' });
  const name = clean(req.body.name, 200), category = clean(req.body.category, 100), description = clean(req.body.description, 2000), price = Number(req.body.price), stock = Number(req.body.stock);
  if (!name || !category || !Number.isInteger(price) || price < 0 || !Number.isInteger(stock) || stock < 0) return res.status(400).json({ error: 'সব তথ্য সঠিকভাবে দিন।' });
  const image = req.file ? '/uploads/' + req.file.filename : old.image;
  db.prepare('UPDATE products SET name=?,category=?,description=?,price=?,stock=?,image=? WHERE id=?').run(name,category,description,price,stock,image,id);
  res.json({ message: 'Updated.' });
});
app.delete('/api/admin/products/:id', requireAdmin, (req, res) => {
  const result = db.prepare('DELETE FROM products WHERE id = ?').run(Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: 'Product not found.' });
  res.json({ message: 'Deleted.' });
});
app.get('/api/admin/orders', requireAdmin, (req, res) => res.json(db.prepare('SELECT * FROM orders ORDER BY id DESC').all().map(o => ({ ...o, items: JSON.parse(o.items_json) }))));
app.patch('/api/admin/orders/:id', requireAdmin, (req, res) => {
  const id = Number(req.params.id), status = clean(req.body.status, 30);
  const allowed = ['Pending','Confirmed','Processing','Shipped','Delivered','Cancelled'];
  if (!allowed.includes(status)) return res.status(400).json({ error: 'Invalid status.' });
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  if (order.status === status) return res.json({ message: 'Order status unchanged.' });
  const items = JSON.parse(order.items_json);
  const update = db.transaction(() => {
    // Cancelled orders return their reserved stock; un-cancelling reserves it again.
    if (status === 'Cancelled' && order.status !== 'Cancelled') {
      for (const item of items) db.prepare('UPDATE products SET stock = stock + ? WHERE id = ?').run(item.qty, item.id);
    } else if (order.status === 'Cancelled' && status !== 'Cancelled') {
      for (const item of items) {
        const r = db.prepare('UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?').run(item.qty, item.id, item.qty);
        if (!r.changes) throw new Error(`“${item.name}” পর্যাপ্ত স্টকে নেই; অর্ডারটি পুনরায় সক্রিয় করা যাচ্ছে না।`);
      }
    }
    db.prepare('UPDATE orders SET status = ? WHERE id = ?').run(status, id);
  });
  try { update(); res.json({ message: 'Order status updated.' }); }
  catch (e) { res.status(400).json({ error: e.message || 'Order status update failed.' }); }
});
app.get('/admin', (req, res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));
app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) return res.status(400).json({ error: 'ছবি ৩ MB-এর কম হতে হবে।' });
  console.error(err); res.status(500).json({ error: 'Server error.' });
});
app.listen(PORT, () => console.log(`Shikkha Bazar running at http://localhost:${PORT}`));
