# শিক্ষা বাজার — E-commerce starter

A mobile-friendly Bengali book shop with product search/categories, cart, Cash on Delivery checkout, stock-aware order creation, and a protected admin panel for products and order statuses.

## Requirements
- Node.js 18 or newer
- npm

## Run locally
1. Extract the ZIP and open a terminal in this folder.
2. Install packages:
   ```bash
   npm install
   ```
3. Copy `.env.example` to `.env` and set your own values. Use a long random `SESSION_SECRET` and a unique admin password of at least 12 characters. Never publish your `.env` file.
4. Start the app:
   ```bash
   npm start
   ```
5. Open `http://localhost:3000` for the shop and `http://localhost:3000/admin` for admin login.

The first start creates `store.db` and the admin account from `.env`. The starter includes no fake orders. Log in to the admin panel and add your real books, prices, stock and images.

## Features
- Product listing, search, categories, image upload (3 MB max), price and stock
- Cart stored in the browser
- Customer name, phone, address and notes at checkout
- Cash on Delivery (no payment gateway connected)
- Order ID, stock deduction in a database transaction, and admin order status updates
- Safe stock restoration when an order is cancelled or re-activated
- Bengali/English phone-number digit normalization at checkout
- SQLite database stored in `store.db`

## Before public deployment
This is a starter, not a managed production service. Configure HTTPS and `NODE_ENV=production`; set a strong random `SESSION_SECRET`; use a persistent disk for SQLite and uploads; back up `store.db` and `uploads`; configure a production-grade session store instead of Express's default MemoryStore; add CSRF protection and an image-scanning/content validation service; and test restore, stock concurrency, and order flows. Do not reuse the example admin password. The current app uses Helmet and rate-limits admin login, but public deployment needs the additional hardening above.
