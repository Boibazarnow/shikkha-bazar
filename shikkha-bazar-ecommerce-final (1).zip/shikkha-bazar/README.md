# শিক্ষা বাজার (Shikkha Bazar)

Bengali educational book e-commerce starter with product catalog, search/category filter, COD ordering, admin login, product upload/delete, stock tracking and order status management.

## Local run
1. Install Node.js 18+.
2. `npm install`
3. Copy `.env.example` to `.env` and change `ADMIN_PASSWORD` and `SESSION_SECRET`.
4. `npm start`
5. Open `http://localhost:3000`
6. Admin: `http://localhost:3000/admin`

## Render
Build Command: `npm install`
Start Command: `npm start`
Set environment variables: `SESSION_SECRET`, `ADMIN_USER`, `ADMIN_PASSWORD`, and optionally `DB_PATH`.

Important: SQLite data needs persistent storage in production. Use a persistent disk/volume or migrate the database to managed PostgreSQL before serious production use.
